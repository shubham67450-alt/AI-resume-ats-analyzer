import { jsPDF } from 'jspdf';
import type { ResumeAnalysis } from './analyzeResume';

export function createReportPdf(analysis: ResumeAnalysis): void {
  const pdf = new jsPDF({ unit: 'pt', format: 'a4' });
  const margin = 48;
  const width = 595 - margin * 2;
  let y = 56;
  pdf.setTextColor(21, 45, 40);
  pdf.setFont('helvetica', 'bold');
  pdf.setFontSize(22);
  pdf.text('AI Resume ATS Analyzer', margin, y);
  y += 28;
  pdf.setFont('helvetica', 'normal');
  pdf.setFontSize(10);
  pdf.setTextColor(91, 111, 105);
  pdf.text(`Analysis report • ${new Date().toLocaleDateString()}`, margin, y);
  y += 32;
  pdf.setFillColor(231, 246, 239);
  pdf.roundedRect(margin, y, width, 76, 10, 10, 'F');
  pdf.setTextColor(21, 45, 40);
  pdf.setFont('helvetica', 'bold');
  pdf.setFontSize(34);
  pdf.text(String(analysis.score), margin + 18, y + 46);
  pdf.setFontSize(11);
  pdf.text('/ 100 ATS compatibility estimate', margin + 86, y + 42);
  y += 106;
  y = addSection(pdf, 'Score breakdown', analysis.categories.map((category) => `${category.label}: ${category.score}/${category.max} — ${category.detail}`), margin, width, y);
  y = addSection(pdf, 'Contact information', [analysis.contact.name, analysis.contact.email, analysis.contact.phone, analysis.contact.location], margin, width, y);
  y = addSection(pdf, 'Detected skills', [...analysis.skills.technical.map((skill) => `Technical: ${skill}`), ...analysis.skills.soft.map((skill) => `Soft skill: ${skill}`)], margin, width, y);
  y = addSection(pdf, 'Formatting checks', analysis.formatting.map((item) => `${item.label}: ${item.detail}`), margin, width, y);
  y = addSection(pdf, 'Priority recommendations', analysis.recommendations.map((item) => `${item.priority} — ${item.title}: ${item.action}`), margin, width, y);
  y = addSection(pdf, 'Suggested professional summary', [analysis.summary], margin, width, y);
  pdf.setFontSize(8);
  pdf.setTextColor(120, 130, 126);
  pdf.text('This score is an estimate based on detectable resume content and is not a guarantee for every employer ATS.', margin, 806);
  pdf.save('resume-ats-analysis.pdf');
}

function addSection(pdf: jsPDF, title: string, lines: string[], margin: number, width: number, startY: number): number {
  let y = startY;
  if (y > 744) { pdf.addPage(); y = 56; }
  pdf.setTextColor(16, 122, 91);
  pdf.setFont('helvetica', 'bold');
  pdf.setFontSize(13);
  pdf.text(title, margin, y);
  y += 19;
  pdf.setTextColor(55, 70, 65);
  pdf.setFont('helvetica', 'normal');
  pdf.setFontSize(9);
  for (const line of lines.length ? lines : ['None detected']) {
    const wrapped = pdf.splitTextToSize(`• ${line}`, width);
    if (y + wrapped.length * 13 > 780) { pdf.addPage(); y = 56; }
    pdf.text(wrapped, margin, y);
    y += wrapped.length * 13 + 5;
  }
  return y + 12;
}
