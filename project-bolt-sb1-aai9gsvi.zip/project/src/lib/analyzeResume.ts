export type ScoreCategory = {
  label: string;
  score: number;
  max: number;
  detail: string;
};

export type ResumeAnalysis = {
  score: number;
  categories: ScoreCategory[];
  contact: { name: string; email: string; phone: string; location: string };
  sections: string[];
  skills: { technical: string[]; soft: string[] };
  highlights: string[];
  formatting: { label: string; status: 'pass' | 'warn' | 'info'; detail: string }[];
  recommendations: { priority: 'High' | 'Medium' | 'Low'; title: string; why: string; action: string }[];
  summary: string;
  parsedReliably: boolean;
};

const technicalSkillGroups: Record<string, string[]> = {
  Languages: ['javascript', 'typescript', 'python', 'java', 'c++', 'c#', 'go', 'ruby', 'php', 'sql', 'html', 'css'],
  Frameworks: ['react', 'next.js', 'angular', 'vue', 'node.js', 'express', 'django', 'spring', 'tailwind'],
  Data: ['postgresql', 'mysql', 'mongodb', 'redis', 'pandas', 'tableau', 'power bi', 'excel'],
  Cloud: ['aws', 'azure', 'gcp', 'docker', 'kubernetes', 'terraform', 'git', 'github', 'gitlab'],
};
const softSkillTerms = ['leadership', 'communication', 'collaboration', 'teamwork', 'problem solving', 'critical thinking', 'mentoring', 'adaptability', 'time management', 'stakeholder management'];
const sectionPatterns: Record<string, RegExp> = {
  Summary: /(^|\n)\s*(summary|professional summary|profile|objective)\s*($|\n)/i,
  Experience: /(^|\n)\s*(experience|work experience|employment history|professional experience)\s*($|\n)/i,
  Education: /(^|\n)\s*(education|academic background)\s*($|\n)/i,
  Skills: /(^|\n)\s*(skills|technical skills|core competencies|competencies)\s*($|\n)/i,
  Projects: /(^|\n)\s*(projects|selected projects|personal projects)\s*($|\n)/i,
  Certifications: /(^|\n)\s*(certifications|licenses)\s*($|\n)/i,
};

export function analyzeResume(text: string, fileName = ''): ResumeAnalysis {
  const normalized = text.trim();
  const lower = normalized.toLowerCase();
  const lines = normalized.split('\n').map((line) => line.trim()).filter(Boolean);
  const sections = Object.entries(sectionPatterns).filter(([, pattern]) => pattern.test(normalized)).map(([label]) => label);
  const email = normalized.match(/[\w.+-]+@[\w-]+\.[\w.-]+/)?.[0] ?? '';
  const phone = normalized.match(/(?:\+?\d[\d\s().-]{7,}\d)/)?.[0]?.trim() ?? '';
  const firstLine = lines.find((line) => line.length > 2 && line.length < 70 && !/@|\d{3}/.test(line)) ?? '';
  const location = lines.find((line) => /,\s*[A-Za-z]{2,}|remote|new york|london|toronto|san francisco/i.test(line)) ?? '';
  const technical = Object.values(technicalSkillGroups).flat().filter((skill) => new RegExp(`(^|[^a-z])${escapeRegExp(skill)}([^a-z]|$)`, 'i').test(lower)).map(formatSkill);
  const soft = softSkillTerms.filter((skill) => lower.includes(skill)).map(formatSkill);
  const hasBullets = /(^|\n)\s*([-•*▪◦]|\d+[.)])\s+/.test(normalized);
  const hasDates = /\b(?:19|20)\d{2}\b|\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{4}\b/i.test(normalized);
  const measurable = /\b\d+(?:%|\+|\s*(?:people|users|projects|clients|hours|months|years|k|m))\b/i.test(normalized);
  const formattingRisk = /\t{2,}|\|{2,}|\[table\]|\btext box\b/i.test(normalized);
  const hasContact = Boolean(email || phone);
  const hasCoreSections = ['Experience', 'Education', 'Skills'].filter((section) => sections.includes(section)).length;
  const readableScore = Math.min(25, Math.max(8, 15 + (hasBullets ? 4 : 0) + (lines.length > 20 ? 3 : 0) - (formattingRisk ? 7 : 0)));
  const structureScore = Math.min(20, hasCoreSections * 5 + (sections.includes('Summary') ? 3 : 0) + (sections.includes('Projects') ? 2 : 0));
  const contactScore = Math.min(10, (email ? 6 : 0) + (phone ? 3 : 0) + (location ? 1 : 0));
  const skillsScore = Math.min(15, Math.min(10, technical.length * 2) + Math.min(5, soft.length));
  const experienceScore = Math.min(20, (sections.includes('Experience') ? 10 : 0) + (hasBullets ? 5 : 0) + (measurable ? 5 : 0));
  const clarityScore = Math.min(10, (hasDates ? 4 : 0) + (normalized.length > 350 ? 3 : 0) + (lines.length > 8 ? 3 : 0));
  const categories: ScoreCategory[] = [
    { label: 'Parsing & readability', score: readableScore, max: 25, detail: formattingRisk ? 'Potential layout markers may interrupt text parsing.' : 'Text is readable with a generally parseable flow.' },
    { label: 'Structure & sections', score: structureScore, max: 20, detail: `${hasCoreSections} of the three core sections were detected.` },
    { label: 'Contact details', score: contactScore, max: 10, detail: hasContact ? 'Contact details were detected in the extracted text.' : 'No clear email address or phone number was detected.' },
    { label: 'Skills presentation', score: skillsScore, max: 15, detail: `${technical.length + soft.length} supported skill${technical.length + soft.length === 1 ? '' : 's'} detected.` },
    { label: 'Experience & achievements', score: experienceScore, max: 20, detail: measurable ? 'Some measurable evidence appears in the resume.' : 'Add measurable evidence only where it reflects real work.' },
    { label: 'Consistency & clarity', score: clarityScore, max: 10, detail: hasDates ? 'Dates were detected; keep their format consistent throughout.' : 'No consistent employment dates were detected.' },
  ];
  const total = categories.reduce((sum, category) => sum + category.score, 0);
  const recommendations = buildRecommendations({ email, phone, sections, hasBullets, measurable, hasDates, formattingRisk, technical, normalized });
  const summary = buildSummary(firstLine, sections, technical, normalized);
  return {
    score: total,
    categories,
    contact: { name: firstLine || 'Not detected', email: email || 'Not detected', phone: phone || 'Not detected', location: location || 'Not detected' },
    sections,
    skills: { technical, soft },
    highlights: buildHighlights({ fileName, sections, technical, soft, hasBullets, measurable }),
    formatting: buildFormatting({ formattingRisk, sections, hasDates, hasBullets }),
    recommendations,
    summary,
    parsedReliably: normalized.length >= 40,
  };
}

function buildRecommendations(input: { email: string; phone: string; sections: string[]; hasBullets: boolean; measurable: boolean; hasDates: boolean; formattingRisk: boolean; technical: string[]; normalized: string }): ResumeAnalysis['recommendations'] {
  const items: ResumeAnalysis['recommendations'] = [];
  if (!input.email || !input.phone) items.push({ priority: 'High', title: 'Complete your contact line', why: 'Recruiters and ATS systems need a reliable way to identify and reach you.', action: `Add ${!input.email ? 'a professional email address' : ''}${!input.email && !input.phone ? ' and ' : ''}${!input.phone ? 'a phone number' : ''} near your name.` });
  if (!input.sections.includes('Experience')) items.push({ priority: 'High', title: 'Add a standard experience section', why: 'A clearly labeled work history helps parsers connect roles, employers, and dates.', action: 'Use a heading such as “Experience” or “Work Experience” and list roles in reverse chronological order.' });
  if (!input.hasBullets) items.push({ priority: 'High', title: 'Turn responsibilities into bullets', why: 'Short, consistently formatted bullets are easier to scan and parse than dense paragraphs.', action: 'Start each bullet with an action verb and describe the outcome using only facts from your experience.' });
  if (!input.measurable) items.push({ priority: 'Medium', title: 'Look for evidence you can quantify', why: 'Specific scope or outcomes make genuine achievements clearer to a reader.', action: 'Ask yourself which results, volumes, timeframes, or improvements are already supported by your actual work.' });
  if (!input.hasDates) items.push({ priority: 'Medium', title: 'Make employment dates explicit', why: 'Consistent month and year dates help ATS systems understand your timeline.', action: 'Use one format consistently, such as “Jan 2023 – Mar 2025,” for every role and education entry.' });
  if (input.formattingRisk) items.push({ priority: 'High', title: 'Simplify complex layout elements', why: 'Tables, columns, and unusual separators can change reading order during parsing.', action: 'Prefer one column, standard headings, and simple text formatting for the version you submit online.' });
  if (!input.sections.includes('Summary')) items.push({ priority: 'Low', title: 'Add a focused professional summary', why: 'A short opening summary can make your experience and strongest skills easier to understand quickly.', action: 'Use the suggested summary below as a starting point, then edit it so every statement remains accurate.' });
  if (!input.technical.length) items.push({ priority: 'Medium', title: 'Make relevant skills easier to find', why: 'A dedicated skills section improves scanning and helps surface tools you explicitly use.', action: 'Add a clearly labeled skills section containing only technologies and capabilities supported by your background.' });
  return items.slice(0, 6);
}

function buildFormatting(input: { formattingRisk: boolean; sections: string[]; hasDates: boolean; hasBullets: boolean }): ResumeAnalysis['formatting'] {
  return [
    { label: 'Readable text structure', status: input.formattingRisk ? 'warn' : 'pass', detail: input.formattingRisk ? 'Possible table, column, or separator patterns were detected.' : 'The extracted text follows a readable single-flow structure.' },
    { label: 'Standard section headings', status: input.sections.length >= 3 ? 'pass' : 'warn', detail: input.sections.length >= 3 ? `${input.sections.length} recognizable headings were found.` : 'Use common headings such as Experience, Education, Skills, and Projects.' },
    { label: 'Date consistency', status: input.hasDates ? 'info' : 'warn', detail: input.hasDates ? 'Date-like values were found; review them for consistent formatting.' : 'Employment or education dates were not clearly detected.' },
    { label: 'Bullet readability', status: input.hasBullets ? 'pass' : 'warn', detail: input.hasBullets ? 'Bullet-style lines were detected for scan-friendly content.' : 'No consistent bullet structure was detected.' },
  ];
}

function buildHighlights(input: { fileName: string; sections: string[]; technical: string[]; soft: string[]; hasBullets: boolean; measurable: boolean }): string[] {
  return [
    input.fileName ? `${input.fileName} was processed without permanent storage.` : 'Resume text was analyzed from the provided content.',
    `${input.sections.length} standard resume section${input.sections.length === 1 ? '' : 's'} detected.`,
    `${input.technical.length + input.soft.length} explicit skill${input.technical.length + input.soft.length === 1 ? '' : 's'} found; no unsupported skills were added.`,
    input.hasBullets ? 'Bullet formatting is present in the extracted text.' : 'Bullet formatting could not be confirmed from the extracted text.',
    input.measurable ? 'At least one measurable detail was detected.' : 'No measurable detail was confidently detected.',
  ];
}

function buildSummary(firstLine: string, sections: string[], technical: string[], text: string): string {
  const name = firstLine && !/resume|curriculum vitae/i.test(firstLine) ? firstLine : 'Professional';
  const experiencePhrase = sections.includes('Experience') ? 'with experience documented in the resume' : 'with a resume focused on developing professional experience';
  const skillsPhrase = technical.length ? ` Skilled in ${technical.slice(0, 4).join(', ')}.` : ' Add your most relevant verified skills here.';
  const lengthPhrase = text.length > 1200 ? ' Brings a detailed background presented across multiple resume sections.' : '';
  return `${name} is a ${experiencePhrase}.${skillsPhrase}${lengthPhrase}`;
}

function formatSkill(skill: string): string { return skill.replace(/\b\w/g, (letter) => letter.toUpperCase()); }
function escapeRegExp(value: string): string { return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
