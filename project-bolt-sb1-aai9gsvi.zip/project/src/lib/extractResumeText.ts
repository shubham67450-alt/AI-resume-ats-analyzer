import mammoth from 'mammoth/mammoth.browser';
import { getDocument, GlobalWorkerOptions } from 'pdfjs-dist';

GlobalWorkerOptions.workerSrc = new URL('pdfjs-dist/build/pdf.worker.min.mjs', import.meta.url).toString();

export const MAX_FILE_SIZE = 5 * 1024 * 1024;

export class ResumeExtractionError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ResumeExtractionError';
  }
}

export async function extractResumeText(file: File): Promise<string> {
  if (file.size > MAX_FILE_SIZE) {
    throw new ResumeExtractionError('This file is larger than 5 MB. Please choose a smaller resume.');
  }

  const extension = file.name.toLowerCase().split('.').pop();
  if (extension !== 'pdf' && extension !== 'docx') {
    throw new ResumeExtractionError('Unsupported format. Please upload a PDF or DOCX file.');
  }

  try {
    const buffer = await file.arrayBuffer();
    const text = extension === 'pdf' ? await extractPdfText(buffer) : await extractDocxText(buffer);
    const cleaned = normalizeExtractedText(text);
    if (cleaned.length < 40) {
      throw new ResumeExtractionError('The file did not contain enough readable text. Try pasting your resume instead.');
    }
    return cleaned;
  } catch (error) {
    if (error instanceof ResumeExtractionError) throw error;
    throw new ResumeExtractionError('This resume could not be read. The file may be corrupted or image-only.');
  }
}

async function extractPdfText(buffer: ArrayBuffer): Promise<string> {
  const pdf = await getDocument({ data: buffer }).promise;
  const pages: string[] = [];
  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
    const page = await pdf.getPage(pageNumber);
    const content = await page.getTextContent();
    pages.push(content.items.map((item) => ('str' in item ? item.str : '')).join(' '));
  }
  return pages.join('\n');
}

async function extractDocxText(buffer: ArrayBuffer): Promise<string> {
  const result = await mammoth.extractRawText({ arrayBuffer: buffer });
  return result.value;
}

function normalizeExtractedText(text: string): string {
  return text
    .split('')
    .filter((character) => character === '\n' || character === '\t' || character.charCodeAt(0) >= 32)
    .join('')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n\s*\n\s*\n+/g, '\n\n')
    .trim();
}
