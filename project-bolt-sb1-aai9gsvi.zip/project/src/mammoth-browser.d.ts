declare module 'mammoth/mammoth.browser' {
  type ExtractResult = { value: string; messages: unknown[] };
  export function extractRawText(input: { arrayBuffer: ArrayBuffer }): Promise<ExtractResult>;
}
