import { useRef, useState, type ChangeEvent, type DragEvent } from 'react';
import { AlertCircle, ArrowRight, Check, CheckCircle2, ChevronDown, Clipboard, CloudUpload, Copy, FileText, FileWarning, Gauge, Info, LoaderCircle, Mail, MapPin, Phone, RefreshCw, ShieldCheck, Sparkles, Trash2, X } from 'lucide-react';
import { analyzeResume, type ResumeAnalysis } from '@/lib/analyzeResume';
import { createReportPdf } from '@/lib/createReport';
import { extractResumeText, ResumeExtractionError } from '@/lib/extractResumeText';

type AppStep = 'upload' | 'processing' | 'results';
type Toast = { type: 'success' | 'error'; message: string } | null;

function App() {
  const [step, setStep] = useState<AppStep>('upload');
  const [file, setFile] = useState<File | null>(null);
  const [resumeText, setResumeText] = useState('');
  const [analysis, setAnalysis] = useState<ResumeAnalysis | null>(null);
  const [error, setError] = useState('');
  const [toast, setToast] = useState<Toast>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = async (nextFile: File) => {
    setError('');
    setFile(nextFile);
    setResumeText('');
    setStep('processing');
    try {
      const extractedText = await extractResumeText(nextFile);
      setResumeText(extractedText);
      setStep('upload');
      setToast({ type: 'success', message: 'Resume text extracted and ready to analyze.' });
    } catch (err) {
      setFile(null);
      setStep('upload');
      setError(err instanceof ResumeExtractionError ? err.message : 'We could not read this file. Please try again.');
    }
  };

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const selected = event.target.files?.[0];
    if (selected) void handleFile(selected);
    event.target.value = '';
  };

  const handleDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragging(false);
    const dropped = event.dataTransfer.files[0];
    if (dropped) void handleFile(dropped);
  };

  const runAnalysis = () => {
    if (resumeText.trim().length < 40) {
      setError('Add at least a few lines of readable resume text before analyzing.');
      return;
    }
    setError('');
    setStep('processing');
    window.setTimeout(() => {
      setAnalysis(analyzeResume(resumeText, file?.name));
      setStep('results');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 650);
  };

  const reset = () => {
    setStep('upload');
    setFile(null);
    setResumeText('');
    setAnalysis(null);
    setError('');
    setToast(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const copyText = async (text: string, message: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setToast({ type: 'success', message });
    } catch {
      setToast({ type: 'error', message: 'Copying is unavailable in this browser.' });
    }
  };

  return (
    <div className="min-h-screen bg-sand text-ink">
      <header className="border-b border-line bg-sand/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 lg:px-8">
          <button type="button" onClick={reset} className="flex items-center gap-3 text-left" aria-label="Start a new analysis">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-forest text-white shadow-sm"><Sparkles size={19} strokeWidth={2.3} /></span>
            <span><span className="block text-sm font-bold tracking-tight text-ink">ResumeLens</span><span className="block text-[11px] font-medium text-muted">ATS analyzer</span></span>
          </button>
          <div className="hidden items-center gap-5 text-xs font-semibold text-muted sm:flex"><span className="flex items-center gap-1.5"><ShieldCheck size={15} className="text-forest" /> Private by design</span><span className="h-1 w-1 rounded-full bg-line" /><span>No job matching</span></div>
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-5 pb-20 pt-10 lg:px-8 lg:pt-14">
        {step === 'results' && analysis ? <ResultsView analysis={analysis} onReset={reset} onCopy={copyText} /> : <UploadView file={file} resumeText={resumeText} error={error} step={step} isDragging={isDragging} fileInputRef={fileInputRef} onTextChange={setResumeText} onChoose={() => fileInputRef.current?.click()} onFileChange={handleFileChange} onDrop={handleDrop} onDragOver={(event) => { event.preventDefault(); setIsDragging(true); }} onDragLeave={() => setIsDragging(false)} onRemove={() => { setFile(null); setResumeText(''); setError(''); }} onAnalyze={runAnalysis} />}
      </main>
      {toast && <div className={`fixed bottom-5 right-5 z-20 flex max-w-sm items-center gap-3 rounded-xl border px-4 py-3 text-sm font-semibold shadow-lg ${toast.type === 'success' ? 'border-mint bg-white text-forest' : 'border-red-200 bg-white text-red-700'}`}><span className={`grid h-7 w-7 place-items-center rounded-full ${toast.type === 'success' ? 'bg-mint' : 'bg-red-50'}`}>{toast.type === 'success' ? <Check size={15} /> : <AlertCircle size={15} />}</span>{toast.message}<button type="button" onClick={() => setToast(null)} className="ml-2 text-muted"><X size={15} /></button></div>}
    </div>
  );
}

type UploadProps = { file: File | null; resumeText: string; error: string; step: AppStep; isDragging: boolean; fileInputRef: React.RefObject<HTMLInputElement>; onTextChange: (value: string) => void; onChoose: () => void; onFileChange: (event: ChangeEvent<HTMLInputElement>) => void; onDrop: (event: DragEvent<HTMLDivElement>) => void; onDragOver: (event: DragEvent<HTMLDivElement>) => void; onDragLeave: () => void; onRemove: () => void; onAnalyze: () => void };

function UploadView({ file, resumeText, error, step, isDragging, fileInputRef, onTextChange, onChoose, onFileChange, onDrop, onDragOver, onDragLeave, onRemove, onAnalyze }: UploadProps) {
  const hasText = resumeText.trim().length >= 40;
  return <div className="mx-auto max-w-5xl">
    <div className="mb-10 max-w-3xl"><div className="eyebrow"><span className="eyebrow-dot" /> Resume clarity, without the guesswork</div><h1 className="mt-5 text-4xl font-bold leading-[1.08] tracking-[-0.04em] text-ink sm:text-6xl">Know how your resume <span className="text-forest">reads to an ATS.</span></h1><p className="mt-5 max-w-2xl text-base leading-7 text-muted sm:text-lg">Get a transparent compatibility estimate, find the friction points, and improve your resume using only the experience you actually provided.</p></div>
    <div className="mb-8 grid gap-4 sm:grid-cols-3"><MiniFeature icon={<Gauge size={17} />} label="Evidence-based" text="A visible score breakdown" /><MiniFeature icon={<FileText size={17} />} label="Resume-only" text="No job description needed" /><MiniFeature icon={<ShieldCheck size={17} />} label="Private by design" text="Temporary processing only" /></div>
    <section className="surface overflow-hidden"><div className="border-b border-line px-6 py-5 sm:px-8"><div className="flex items-center justify-between gap-4"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-forest">Step 1 of 2</p><h2 className="mt-1 text-xl font-bold text-ink">Add your resume</h2></div><span className="rounded-full bg-mint px-3 py-1 text-xs font-bold text-forest">PDF or DOCX · 5 MB max</span></div></div><div className="space-y-6 p-6 sm:p-8">
      {step === 'processing' ? <div className="flex min-h-64 flex-col items-center justify-center rounded-2xl border border-line bg-white"><LoaderCircle className="animate-spin text-forest" size={31} /><p className="mt-4 font-bold text-ink">Reading your resume…</p><p className="mt-1 text-sm text-muted">We are extracting text before analysis begins.</p></div> : file ? <FileReady file={file} textLength={resumeText.length} onRemove={onRemove} /> : <div className={`upload-zone ${isDragging ? 'upload-zone-active' : ''}`} onDrop={onDrop} onDragOver={onDragOver} onDragLeave={onDragLeave} onClick={onChoose} role="button" tabIndex={0} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') onChoose(); }}><input ref={fileInputRef} className="hidden" type="file" accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document" onChange={onFileChange} /><span className="upload-icon"><CloudUpload size={25} /></span><h3 className="mt-4 text-base font-bold text-ink">Drop your resume here</h3><p className="mt-1 text-sm text-muted">or <span className="font-bold text-forest">browse files</span> from your device</p><p className="mt-5 text-xs text-muted">Your document is processed temporarily and not saved.</p></div>}
      <div className="flex items-center gap-3 text-xs font-bold uppercase tracking-[0.14em] text-muted"><span className="h-px flex-1 bg-line" />Or paste text<span className="h-px flex-1 bg-line" /></div>
      <div><textarea value={resumeText} onChange={(event) => onTextChange(event.target.value)} className="input min-h-48 resize-y" placeholder="Paste the readable text from your resume here…" aria-label="Resume text" /><div className="mt-2 flex justify-between text-xs text-muted"><span>We analyze only what you provide.</span><span>{resumeText.length.toLocaleString()} characters</span></div></div>
      {error && <div className="flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium leading-5 text-red-700"><AlertCircle size={17} className="mt-0.5 shrink-0" />{error}</div>}
      <button type="button" onClick={onAnalyze} disabled={!hasText} className="button-primary w-full sm:w-auto">Analyze my resume <ArrowRight size={17} /></button>
    </div></section>
    <p className="mt-5 flex items-start gap-2 text-xs leading-5 text-muted"><Info size={15} className="mt-0.5 shrink-0 text-forest" />This is an estimate based on detectable resume content, not a guarantee of passing every employer’s ATS.</p>
  </div>;
}

function MiniFeature({ icon, label, text }: { icon: React.ReactNode; label: string; text: string }) { return <div className="flex items-center gap-3 rounded-xl border border-line bg-white/60 px-4 py-3"><span className="grid h-9 w-9 place-items-center rounded-lg bg-mint text-forest">{icon}</span><span><b className="block text-sm text-ink">{label}</b><small className="text-xs text-muted">{text}</small></span></div>; }
function FileReady({ file, textLength, onRemove }: { file: File; textLength: number; onRemove: () => void }) { return <div className="flex items-center justify-between gap-4 rounded-2xl border border-mint bg-mint/40 p-4"><div className="flex min-w-0 items-center gap-3"><span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white text-forest"><FileText size={21} /></span><div className="min-w-0"><p className="truncate text-sm font-bold text-ink">{file.name}</p><p className="mt-1 text-xs text-muted">{formatBytes(file.size)} · {textLength.toLocaleString()} characters extracted</p></div></div><button type="button" onClick={onRemove} className="icon-button" aria-label="Remove resume"><Trash2 size={17} /></button></div>; }

function ResultsView({ analysis, onReset, onCopy }: { analysis: ResumeAnalysis; onReset: () => void; onCopy: (text: string, message: string) => void }) {
  const [openRecommendation, setOpenRecommendation] = useState<number | null>(0);
  const reportText = createReportText(analysis);
  return <div className="space-y-8"><div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><div className="eyebrow"><span className="eyebrow-dot" /> Analysis complete</div><h1 className="mt-4 text-4xl font-bold tracking-[-0.04em] text-ink sm:text-5xl">Your resume, <span className="text-forest">decoded.</span></h1><p className="mt-3 text-sm text-muted">A transparent review of what an ATS can detect in your resume.</p></div><div className="flex flex-wrap gap-2"><button type="button" onClick={onReset} className="button-secondary"><RefreshCw size={16} /> New analysis</button><button type="button" onClick={() => createReportPdf(analysis)} className="button-primary"><FileText size={16} /> Download PDF</button></div></div>
    <div className="grid gap-5 lg:grid-cols-[1.02fr_1.98fr]"><ScoreCard analysis={analysis} /><div className="grid gap-5 sm:grid-cols-2"><InfoCard icon={<Mail size={17} />} label="Contact detected" value={analysis.contact.email !== 'Not detected' ? 'Ready to reach' : 'Needs attention'} detail={analysis.contact.email !== 'Not detected' ? analysis.contact.email : 'No clear email found'} tone={analysis.contact.email !== 'Not detected' ? 'good' : 'warn'} /><InfoCard icon={<FileText size={17} />} label="Sections found" value={`${analysis.sections.length} sections`} detail={analysis.sections.join(' · ') || 'No standard headings'} tone={analysis.sections.length >= 3 ? 'good' : 'warn'} /><InfoCard icon={<Sparkles size={17} />} label="Explicit skills" value={`${analysis.skills.technical.length + analysis.skills.soft.length} detected`} detail="Only skills found in your text" tone="good" /><InfoCard icon={<ShieldCheck size={17} />} label="Processing" value="Temporary only" detail="Your resume was not saved" tone="good" /></div></div>
    <section className="surface p-6 sm:p-8"><SectionHeading eyebrow="What stood out" title="Quick read" /><div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">{analysis.highlights.map((highlight) => <div key={highlight} className="rounded-xl border border-line bg-white p-4"><CheckCircle2 size={18} className="text-forest" /><p className="mt-3 text-sm font-semibold leading-5 text-ink">{highlight}</p></div>)}</div></section>
    <div className="grid gap-8 xl:grid-cols-[1.1fr_0.9fr]"><section className="surface p-6 sm:p-8"><SectionHeading eyebrow="Scoring model" title="Where your score comes from" /><div className="mt-7 space-y-5">{analysis.categories.map((category) => <ScoreRow key={category.label} category={category} />)}</div></section><section className="surface p-6 sm:p-8"><SectionHeading eyebrow="Resume snapshot" title="Detected details" /><div className="mt-6 space-y-4"><ContactLine icon={<FileText size={16} />} label="Name" value={analysis.contact.name} /><ContactLine icon={<Mail size={16} />} label="Email" value={analysis.contact.email} /><ContactLine icon={<Phone size={16} />} label="Phone" value={analysis.contact.phone} /><ContactLine icon={<MapPin size={16} />} label="Location" value={analysis.contact.location} /></div><div className="mt-7 border-t border-line pt-6"><p className="text-xs font-bold uppercase tracking-[0.15em] text-muted">Skills found</p><div className="mt-3 flex flex-wrap gap-2">{[...analysis.skills.technical, ...analysis.skills.soft].length ? [...analysis.skills.technical, ...analysis.skills.soft].map((skill) => <span key={skill} className="tag">{skill}</span>) : <span className="text-sm text-muted">No supported skills were detected.</span>}</div></div></section></div>
    <section className="surface p-6 sm:p-8"><SectionHeading eyebrow="Parsing review" title="Formatting checks" /><div className="mt-6 grid gap-3 sm:grid-cols-2">{analysis.formatting.map((item) => <div key={item.label} className="flex items-start gap-3 rounded-xl border border-line bg-white p-4"><StatusIcon status={item.status} /><div><p className="text-sm font-bold text-ink">{item.label}</p><p className="mt-1 text-sm leading-5 text-muted">{item.detail}</p></div></div>)}</div></section>
    <section className="surface p-6 sm:p-8"><div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><SectionHeading eyebrow="Highest impact first" title="Priority fixes" /><span className="rounded-full bg-mint px-3 py-1 text-xs font-bold text-forest">{analysis.recommendations.length} recommendations</span></div><div className="mt-6 space-y-3">{analysis.recommendations.map((recommendation, index) => <div key={recommendation.title} className="rounded-xl border border-line bg-white"><button type="button" onClick={() => setOpenRecommendation(openRecommendation === index ? null : index)} className="flex w-full items-center gap-4 p-4 text-left"><span className={`priority priority-${recommendation.priority.toLowerCase()}`}>{recommendation.priority}</span><span className="flex-1 text-sm font-bold text-ink">{recommendation.title}</span><ChevronDown size={17} className={`text-muted transition-transform ${openRecommendation === index ? 'rotate-180' : ''}`} /></button>{openRecommendation === index && <div className="border-t border-line px-4 pb-5 pt-4 text-sm leading-6 text-muted"><p><b className="text-ink">Why it matters:</b> {recommendation.why}</p><p className="mt-2"><b className="text-ink">Suggested next step:</b> {recommendation.action}</p></div>}</div>)}</div></section>
    <section className="summary-card"><div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-start"><div><div className="eyebrow eyebrow-light"><Sparkles size={13} /> Suggested, not original</div><h2 className="mt-4 text-2xl font-bold tracking-[-0.03em] text-white">A stronger opening</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-white/70">This draft uses only information that was detectable in your resume. Edit it until every word feels true to you.</p></div><button type="button" onClick={() => onCopy(analysis.summary, 'Suggested summary copied to your clipboard.')} className="button-light"><Copy size={16} /> Copy summary</button></div><p className="mt-8 max-w-3xl text-lg font-medium leading-8 text-white">“{analysis.summary}”</p></section>
    <div className="flex flex-col items-center justify-between gap-4 rounded-2xl border border-line bg-white p-5 sm:flex-row"><div className="flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-lg bg-mint text-forest"><Clipboard size={17} /></span><p className="text-sm font-semibold text-ink">Need the full report text somewhere else?</p></div><button type="button" onClick={() => onCopy(reportText, 'Full analysis copied to your clipboard.')} className="button-secondary"><Copy size={16} /> Copy full report</button></div>
  </div>;
}

function ScoreCard({ analysis }: { analysis: ResumeAnalysis }) { const scoreTone = analysis.score >= 75 ? 'Strong foundation' : analysis.score >= 55 ? 'Room to improve' : 'Needs attention'; return <div className="score-card"><div className="flex items-start justify-between"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-white/60">Overall estimate</p><p className="mt-3 text-7xl font-bold tracking-[-0.07em] text-white">{analysis.score}<span className="text-2xl text-white/50">/100</span></p></div><div className="score-ring" style={{ '--score': `${analysis.score * 3.6}deg` } as React.CSSProperties}><span>{analysis.score}</span></div></div><div className="mt-7 border-t border-white/15 pt-5"><p className="font-bold text-white">{scoreTone}</p><p className="mt-1 text-sm leading-6 text-white/65">This score reflects only what could be detected in the submitted resume.</p></div></div>; }
function InfoCard({ icon, label, value, detail, tone }: { icon: React.ReactNode; label: string; value: string; detail: string; tone: 'good' | 'warn' }) { return <div className="surface flex min-h-36 flex-col justify-between p-5"><div className="flex items-center justify-between"><span className="grid h-8 w-8 place-items-center rounded-lg bg-mint text-forest">{icon}</span><span className={`h-2 w-2 rounded-full ${tone === 'good' ? 'bg-green-500' : 'bg-amber-400'}`} /></div><div><p className="mt-4 text-xs font-bold uppercase tracking-[0.12em] text-muted">{label}</p><p className="mt-1 text-base font-bold text-ink">{value}</p><p className="mt-1 truncate text-xs text-muted">{detail}</p></div></div>; }
function SectionHeading({ eyebrow, title }: { eyebrow: string; title: string }) { return <div><p className="text-xs font-bold uppercase tracking-[0.16em] text-forest">{eyebrow}</p><h2 className="mt-2 text-2xl font-bold tracking-[-0.03em] text-ink">{title}</h2></div>; }
function ScoreRow({ category }: { category: ResumeAnalysis['categories'][number] }) { return <div><div className="flex items-center justify-between gap-4 text-sm"><span className="font-bold text-ink">{category.label}</span><span className="font-bold text-forest">{category.score}<span className="font-normal text-muted">/{category.max}</span></span></div><div className="mt-2 h-2 overflow-hidden rounded-full bg-mint"><div className="h-full rounded-full bg-forest transition-all" style={{ width: `${(category.score / category.max) * 100}%` }} /></div><p className="mt-2 text-xs leading-5 text-muted">{category.detail}</p></div>; }
function ContactLine({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) { return <div className="flex items-start gap-3"><span className="mt-0.5 text-forest">{icon}</span><div><p className="text-xs font-bold uppercase tracking-[0.12em] text-muted">{label}</p><p className="mt-1 break-words text-sm font-semibold text-ink">{value}</p></div></div>; }
function StatusIcon({ status }: { status: 'pass' | 'warn' | 'info' }) { return status === 'pass' ? <span className="status-icon status-pass"><Check size={15} /></span> : status === 'warn' ? <span className="status-icon status-warn"><FileWarning size={15} /></span> : <span className="status-icon status-info"><Info size={15} /></span>; }
function createReportText(analysis: ResumeAnalysis): string { return [`AI Resume ATS Analyzer`, `ATS compatibility estimate: ${analysis.score}/100`, '', 'Score breakdown:', ...analysis.categories.map((category) => `${category.label}: ${category.score}/${category.max} — ${category.detail}`), '', 'Detected skills:', ...analysis.skills.technical.map((skill) => `Technical: ${skill}`), ...analysis.skills.soft.map((skill) => `Soft skill: ${skill}`), '', 'Formatting checks:', ...analysis.formatting.map((item) => `${item.label}: ${item.detail}`), '', 'Recommendations:', ...analysis.recommendations.map((item) => `${item.priority} — ${item.title}: ${item.action}`), '', `Suggested summary: ${analysis.summary}`].join('\n'); }
function formatBytes(bytes: number): string { if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`; return `${(bytes / (1024 * 1024)).toFixed(1)} MB`; }

export default App;
